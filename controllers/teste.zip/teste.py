# -*- coding: utf-8 -*-
# tente algo como
def index():
    y = request.vars.cmd
    import serial
    import time

    serialport= serial.Serial ("COM3", 9600, timeout=0.5)
    serialport.write(y)
    response=serialport.readlines(1)
    print response
    time.sleep(10)
    return dict(message=y)
